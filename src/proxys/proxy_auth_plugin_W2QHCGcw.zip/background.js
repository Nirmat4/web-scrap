
chrome.proxy.settings.set({
  value: {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: "brd.superproxy.io",
        port: parseInt(22225)
      },
      bypassList: ["<local>"]
    }
  },
  scope: "regular"
}, function(){});

chrome.webRequest.onAuthRequired.addListener(
  function(details) {
    return {authCredentials: {username: "brd-customer-hl_dbcb7806-zone-test_scrap", password: "gk1x6bsjm4x9"}};
  },
  {urls: ["<all_urls>"]},
  ["blocking"]
);
